"""单例模式工具模块

提供线程安全的单例实现，确保__init__只执行一次。
"""

import threading
from typing import Dict, Type, Any


class SingletonMeta(type):
    """线程安全的单例元类
    
    使用示例:
        class MyClass(metaclass=SingletonMeta):
            def __init__(self, arg1, arg2):
                self.arg1 = arg1
                self.arg2 = arg2
    
    特性:
        1. 线程安全：使用双重检查锁定
        2. __init__只执行一次：避免重复初始化
        3. 支持参数传递：首次创建时的参数会被使用
    """
    
    _instances: Dict[Type, Any] = {}
    _lock: threading.Lock = threading.Lock()
    _initialized: Dict[Type, bool] = {}
    
    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            with cls._lock:
                if cls not in cls._instances:
                    instance = super().__call__(*args, **kwargs)
                    cls._instances[cls] = instance
                    cls._initialized[cls] = True
        return cls._instances[cls]


class Singleton(metaclass=SingletonMeta):
    """单例基类
    
    使用示例:
        class MyClass(Singleton):
            def __init__(self, arg1, arg2):
                if self._is_initialized():
                    return
                self.arg1 = arg1
                self.arg2 = arg2
    
    注意：子类需要在__init__中检查_is_initialized()避免重复初始化
    """
    
    @classmethod
    def _is_initialized(cls) -> bool:
        """检查当前类是否已初始化
        
        Returns:
            bool: 如果已初始化返回True
        """
        return SingletonMeta._initialized.get(cls, False)
    
    @classmethod
    def get_instance(cls, *args, **kwargs):
        """获取单例实例
        
        Args:
            *args: 位置参数（仅在首次创建时使用）
            **kwargs: 关键字参数（仅在首次创建时使用）
            
        Returns:
            单例实例
        """
        return cls(*args, **kwargs)
    
    @classmethod
    def reset_instance(cls):
        """重置单例实例（主要用于测试）
        
        警告：此方法会删除当前实例，下次创建时将生成新实例
        """
        with SingletonMeta._lock:
            if cls in SingletonMeta._instances:
                del SingletonMeta._instances[cls]
            if cls in SingletonMeta._initialized:
                del SingletonMeta._initialized[cls]
