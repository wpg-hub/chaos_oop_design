"""故障注入器注册表模块

提供故障注入器的注册和创建功能，支持装饰器注册和自定义工厂函数。
使用注册机制替代if-else判断，符合开闭原则。
"""

from typing import Dict, Type, Callable, Any, Optional
from abc import ABC


class FaultInjectorRegistry:
    """故障注入器注册表
    
    使用示例:
        # 方式1: 使用装饰器注册
        @FaultInjectorRegistry.register("network")
        class NetworkFaultInjector(FaultInjector):
            pass
        
        # 方式2: 函数调用注册
        FaultInjectorRegistry.register("pod", PodFaultInjector)
        
        # 方式3: 注册带自定义工厂的注入器
        def create_computer_injector(**deps):
            return ComputerFaultInjector(**deps)
        
        FaultInjectorRegistry.register("computer", ComputerFaultInjector, factory=create_computer_injector)
        
        # 创建注入器实例
        injector = FaultInjectorRegistry.create("network", remote_executor=executor, logger=logger)
    """
    
    _registry: Dict[str, Type] = {}
    _factories: Dict[str, Callable[..., Any]] = {}
    
    @classmethod
    def register(cls, fault_type: str, injector_class: Type = None, 
                 factory: Callable[..., Any] = None):
        """注册故障注入器
        
        Args:
            fault_type: 故障类型标识符
            injector_class: 故障注入器类（可选，用于装饰器模式）
            factory: 自定义工厂函数（可选）
            
        Returns:
            如果用作装饰器，返回装饰器函数；否则返回None
        """
        def decorator(injector_cls: Type):
            cls._registry[fault_type] = injector_cls
            if factory:
                cls._factories[fault_type] = factory
            return injector_cls
        
        if injector_class is None:
            # 用作装饰器
            return decorator
        else:
            # 函数调用
            cls._registry[fault_type] = injector_class
            if factory:
                cls._factories[fault_type] = factory
    
    @classmethod
    def create(cls, fault_type: str, **dependencies) -> Any:
        """创建故障注入器实例
        
        Args:
            fault_type: 故障类型
            **dependencies: 依赖项（remote_executor, logger, config_manager等）
            
        Returns:
            故障注入器实例
            
        Raises:
            ValueError: 如果故障类型未注册
        """
        if fault_type not in cls._registry:
            registered_types = list(cls._registry.keys())
            raise ValueError(f"未知的故障类型：{fault_type}。已注册类型：{registered_types}")
        
        # 如果有自定义工厂，使用工厂创建
        if fault_type in cls._factories:
            return cls._factories[fault_type](**dependencies)
        
        # 否则直接实例化
        injector_class = cls._registry[fault_type]
        return injector_class(**dependencies)
    
    @classmethod
    def get_registered_types(cls) -> list:
        """获取所有已注册的类型"""
        return list(cls._registry.keys())
    
    @classmethod
    def is_registered(cls, fault_type: str) -> bool:
        """检查类型是否已注册"""
        return fault_type in cls._registry
    
    @classmethod
    def unregister(cls, fault_type: str) -> bool:
        """注销故障类型（主要用于测试）
        
        Args:
            fault_type: 故障类型
            
        Returns:
            bool: 是否成功注销
        """
        if fault_type in cls._registry:
            del cls._registry[fault_type]
            if fault_type in cls._factories:
                del cls._factories[fault_type]
            return True
        return False
    
    @classmethod
    def clear(cls):
        """清空所有注册（主要用于测试）"""
        cls._registry.clear()
        cls._factories.clear()
