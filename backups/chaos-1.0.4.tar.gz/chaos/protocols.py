"""协议定义模块

定义项目中使用的抽象接口，用于类型提示和依赖注入。
此模块不依赖其他业务模块，避免循环导入。
"""

from typing import Dict, List, Optional, Protocol, Tuple, Any


# ========== 配置管理协议 ==========

class ConfigManagerProtocol(Protocol):
    """配置管理器协议"""
    
    def get_environment(self, name: str) -> Optional[Dict[str, Any]]:
        """获取环境配置"""
        ...
    
    def get_defaults(self) -> Dict[str, Any]:
        """获取默认配置"""
        ...
    
    @property
    def config(self) -> Dict[str, Any]:
        """获取完整配置"""
        ...


class EnvironmentConfigProtocol(Protocol):
    """环境配置协议"""
    
    ip: str
    port: int
    user: str
    passwd: str
    nodename: Optional[str]


# ========== 故障注入协议 ==========

class FaultInjectorProtocol(Protocol):
    """故障注入器协议"""
    
    def inject(self, target: Dict, parameters: Dict) -> bool:
        """注入故障"""
        ...
    
    def recover(self, fault_id: str) -> bool:
        """恢复故障"""
        ...
    
    def get_fault_id(self) -> Optional[str]:
        """获取故障 ID"""
        ...


class FaultFactoryProtocol(Protocol):
    """故障工厂协议"""
    
    def create_injector(self, fault_type: str, **dependencies) -> FaultInjectorProtocol:
        """创建故障注入器"""
        ...


# ========== 状态管理协议 ==========

class StateManagerProtocol(Protocol):
    """状态管理器协议"""
    
    def record_fault(
        self,
        case_name: str,
        fault_type: str,
        fault_id: str,
        target: Dict[str, Any],
        parameters: Dict[str, Any]
    ) -> None:
        """记录故障"""
        ...
    
    def mark_recovered(self, fault_id: str) -> None:
        """标记故障已恢复"""
        ...
    
    def mark_failed(self, fault_id: str, error_message: str) -> None:
        """标记故障失败"""
        ...
    
    def get_fault_state(self, fault_id: str) -> Optional[Dict[str, Any]]:
        """获取故障状态"""
        ...


# ========== 工具类协议 ==========

class RemoteExecutorProtocol(Protocol):
    """远程执行器协议"""
    
    def execute(self, command: str, ignore_errors: bool = False) -> Tuple[bool, str]:
        """执行命令"""
        ...
    
    def connect(self) -> bool:
        """连接"""
        ...
    
    def is_alive(self) -> bool:
        """检查连接是否存活"""
        ...


class LoggerProtocol(Protocol):
    """日志记录器协议"""
    
    def info(self, message: str) -> None:
        """记录信息日志"""
        ...
    
    def error(self, message: str) -> None:
        """记录错误日志"""
        ...
    
    def warning(self, message: str) -> None:
        """记录警告日志"""
        ...
    
    def debug(self, message: str) -> None:
        """记录调试日志"""
        ...
